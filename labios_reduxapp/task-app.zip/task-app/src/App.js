import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTask, removeTask } from "./redux/taskSlice";
import "./App.css";

export default function App() {
  const [input, setInput] = useState("");
  const dispatch = useDispatch();
  const tasks = useSelector((state) => state.tasks.list);

  const handleAdd = () => {
    if (!input.trim()) return;
    dispatch(addTask(input.trim()));
    setInput("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleAdd();
  };

  return (
    <div className="wrapper">
      <div className="card">
        <h1 className="heading">My Task List</h1>
        <p className="subtext">Type a task and press Add</p>

        <div className="input-row">
          <input
            className="task-input"
            type="text"
            placeholder="What do you need to do?"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <button className="add-btn" onClick={handleAdd}>
            Add
          </button>
        </div>

        <ul className="task-list">
          {tasks.length === 0 && (
            <p className="empty-text">No tasks yet. Add one above!</p>
          )}
          {tasks.map((task, index) => (
            <li className="task-item" key={index}>
              <span>{task}</span>
              <button
                className="delete-btn"
                onClick={() => dispatch(removeTask(index))}
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      </div>

      <p className="footer">Made by Jodel Labios</p>
    </div>
  );
}
